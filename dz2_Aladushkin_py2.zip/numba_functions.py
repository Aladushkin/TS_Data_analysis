from numba import jit, double
import numpy as np
import math

@jit(nopython=True)
def cos_sim(a, b):
    return num_dot(a, b)/num_norm(a)/num_norm(b)

@jit(nopython=True)
def num_dot(a, b):
    N = a.shape[0]
    out = 0.
    for i in range(N):
        out += a[i]*b[i]

    return out

@jit(nopython=True)
def num_norm(vec):
    out = 0.
    N = vec.shape[0]
    for i in range(N):
        out += vec[i] ** 2
    out = math.sqrt(out)

    return out

@jit(nopython=True)
def stand_dev(matrix, mean_row):

    N = matrix.shape[0]
    M = matrix.shape[1]

    sq_dev = np.zeros((N,))
    for i in range(N):
        sum = 0.
        for j in range(M):
            sum += (matrix[i][j] - mean_row[i]) ** 2
        sum = math.sqrt(sum/M)
        sq_dev[i] = sum
    return sq_dev


@jit(nopython=True)
def matrix_multiply(X, Y):
    """ Matrix multiplication
    Inputs:
      - X: A numpy array of shape (N, M)
      - Y: A numpy array of shape (M, K)
    Output:
      - out: A numpy array of shape (N, K)
    """

    N = X.shape[0]
    M = X.shape[1]
    K = Y.shape[1]

    out = np.zeros((N,K))

    for i in range(N):
        for j in range(K):
            for k in range(M):
                    out[i][j] += X[i][k] * Y[k][j];
    return out


@jit(nopython=True)
def matrix_rowmean(X, weights=np.empty(0)):
    """ Calculate mean of each row.
    In case of weights do weighted mean.
    For example, for matrix [[1, 2, 3]] and weights [0, 1, 2]
    weighted mean equals 2.6666 (while ordinary mean equals 2)
    Inputs:
      - X: A numpy array of shape (N, M)
      - weights: A numpy array of shape (M,)
    Output:
      - out: A numpy array of shape (N,)
    """
    N = X.shape[0]
    M = X.shape[1]
    out = np.zeros((N,))

    if weights.size == 0:
        for i in range(N):
            sum = 0.
            for j in range(M):
                sum += X[i][j]
            out[i] = sum / M
    else:
        sum_w = 0.
        for i in range(M):
            sum_w += weights[i]

        for i in range(N):
            sum = 0.
            for j in range(M):
                sum += X[i][j] * weights[j]
            out[i] = sum / sum_w

    return out

@jit(nopython = True)
def cosine_similarity(X, top_n=10, with_mean=True, with_std=True):
    """ Calculate cosine similarity between each pair of row.
    1. In case of with_mean: subtract mean of each row from row
    2. In case of with_std: divide each row on it's std
    3. Select top_n best elements in each row or set other to zero.
    4. Compute cosine similarity between each pair of rows.
    Inputs:
      - X: A numpy array of shape (N, M)
      - top_n: int, number of best elements in each row
      - with_mean: bool, in case of subtracting each row's mean
      - with_std: bool, in case of subtracting each row's std
    Output:
      - out: A numpy array of shape (N, N)

    Example (with top_n=1, with_mean=True, with_std=True):
        X = array([[1, 2], [4, 3]])
        after mean and std transform:
        X = array([[-1.,  1.], [ 1., -1.]])
        after top n choice
        X = array([[0.,  1.], [ 1., 0]])
        cosine similarity:
        X = array([[ 1.,  0.], [ 0.,  1.]])

    """
    X = X.astype(double)
    N = X.shape[0]
    M = X.shape[1]
    out = np.zeros((N,N))

    # +

    mean = matrix_rowmean(X)
    if with_mean:
        for i in range(N):
            for j in range(M):
                X[i][j] -= mean[i]

    # +
    if with_std:
        std = stand_dev(X, mean)
        for i in range(N):
            for j in range(M):
                X[i][j] /= std[i]


    for i in range(N):
        y = sorted(X[i])[:-top_n]
        for j in range(len(y)):
            for k in range(M):
                if X[i][k] == y[j]:
                    X[i][k] = 0
                    break


    for i in range(N):
        for j in range(N):
            out[i][j] = cos_sim(X[i], X[j])

    return out

